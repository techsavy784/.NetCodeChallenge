﻿using System;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Xml;

namespace dotnet_code_challenge
{
    class Program
    {
        static void Main(string[] args)
        {
            FetchData.Fetch_WolferhamptonRace_HorseNames();

            // this method is work in progress
            FetchData.Fetch_CaulfieldRace_HorseNames();
        }
    }


    public static class FetchData
    {
        /// <summary>
        /// Fetch Horse Names in Price ascending order from Caulfield Race
        /// </summary>
        public static void Fetch_WolferhamptonRace_HorseNames()
        {
            try
            {
                string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"FeedData\Wolferhampton_Race1.json");
                string wolferhamptonRaceJsonObject = LoadJson(path);
                if (!string.IsNullOrEmpty(wolferhamptonRaceJsonObject))
                {
                    RootObject rootObject = JsonConvert.DeserializeObject<RootObject>(wolferhamptonRaceJsonObject);
                    Dictionary<string, double> horseList = new Dictionary<string, double>();
                    foreach (var selection in rootObject.RawData.Markets.SelectMany(m => m.Selections))
                    {
                        double price = selection.Price;
                        string horseName = selection.Tags.name;
                        horseList.Add(horseName, price);
                    }
                    var sortedHorseList = horseList.OrderBy(key => key.Value);
                    foreach (KeyValuePair<string, double> kvp in sortedHorseList)
                    {
                        Console.WriteLine("Horse Name = {0}, Price = {1}", kvp.Key, kvp.Value);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to Print Horse Names in Ascending Order Wolferhampton Race. " + ex.Message);
            }
        }


        /// <summary>
        /// Fetch Horse Names in Price ascending order from Wolferhampton Race
        /// </summary>
        public static void Fetch_CaulfieldRace_HorseNames()
        {
            try
            {
                string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"FeedData\Caulfield_Race1.xml");
                XmlDocument doc = new XmlDocument();
                doc.Load(path);
                Serializer xmlSer = new Serializer();
                StringWriter sw = new StringWriter();
                XmlTextWriter tx = new XmlTextWriter(sw);
                doc.WriteTo(tx);

                string json = JsonConvert.SerializeXmlNode(doc);
                // CaulfieldRace caulfieldRaceXML = xmlSer.Deserialize<CaulfieldRace>(sw.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to Print Horse Names in Ascending Order Caulfield Race. " + ex.Message);
            }
        }

        /// <summary>
        /// Read json feed data of Wolferhampton Race
        /// </summary>
        /// <returns>string</returns>
        public static string LoadJson(string path)
        {
            try
            {                
                using (StreamReader file = File.OpenText(path))
                using (JsonTextReader reader = new JsonTextReader(file))
                {
                    JObject o2 = (JObject)JToken.ReadFrom(reader);
                    Console.WriteLine("Retrieving data for Wolferhampton Race...  ");
                    return o2.ToString();
                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to Load JSON file for Wolferhampton Race. " + ex.Message);
                return string.Empty;
            }
        }
    }
}
