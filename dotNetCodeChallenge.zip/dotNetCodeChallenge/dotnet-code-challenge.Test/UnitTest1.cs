using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Reflection;
using Xunit;

namespace dotnet_code_challenge.Test
{
    public class UnitTest1
    {
        [Fact]
        public void CanLoadJson()
        {
            // arrange
            string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"testData.json");
            string jsonData = FetchData.LoadJson(path);
            JObject jobject = JObject.Parse(jsonData);

            // act/assert
            Assert.Equal("Ford", jobject["car"]);
        }    
    }
}
